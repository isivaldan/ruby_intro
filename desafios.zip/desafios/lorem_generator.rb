n = ARGV[0].to_i

i = 0

while i < n
    puts "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus tempus pulvinar velit. Donec sed neque dignissim, maximus nulla sed, facilisis ipsum. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vivamus auctor tempor lectus, quis auctor diam rutrum sit amet. Mauris pretium ligula vel blandit venenatis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos."
    puts"\n"
    i+=1
end
